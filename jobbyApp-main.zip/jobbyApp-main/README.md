### JobbyApp

### Set Up Instructions

<details>
<summary>Click to view</summary>

- Download dependencies by running `npm install`
- Start up the app using `npm start`
</details>

Username: "rahul"  Password: "rahul@2021"

### Deployed Link
https://sasijobap1p.ccbp.tech/


